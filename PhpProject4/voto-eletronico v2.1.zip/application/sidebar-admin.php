<?php include "header.php"; ?>
<ul id="menu_nav_side_bar" class="navbar-nav sidebar nav-pills nav-flush d-flex flex-column mb-auto text-center">
    <div class="d-flex justify-content-center mb-3">
        <img class="img-fluid logo" src="https://voto-eletronico.jbr-projects.pt/assets/img/logo.png">
    </div>
    <li class="nav-item">
        <a class="nav-link py-3 tittle-side-bar" id="a-dashboard" onclick="call_page_dashboard()">
            <i id="icon-dashboard" class="fas fa-tachometer-alt icon-class-admin"></i>
            <label class="label-not-display" style="cursor: pointer;">Dashboard</label>
        </a>
    </li>
    <br>
    <li class="nav-item">
        <a class="nav-link py-3 dropdown-toggle tittle-side-bar" id ="a-users">
            <i id="icon-utilizadores" class="fas fa-users icon-class-admin" ></i>
            <br>
            <label class="label-not-display" style="cursor: pointer;">Utilizadores</label>
        </a>
        <div class="collapse" id="collapseUsers">
            <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
                <li class="nav-item tittle-side-bar">
                    <button class="no-btn" type="button" id="btn-user-add" onclick="call_page_add_user()">Adicionar Utilizador</button>
                    <br>
                    <hr class="hr-centered d-flex align-items-center special-class-hr-special" id="hr-special">
                    <button class="no-btn" type="button" id="btn-users-see" onclick="call_page_see_users()">Ver Utilizadores</button>
                </li>
            </ul>
        </div>
    </li>
    <br>
    <li class="nav-item">
        <a class="nav-link py-3 dropdown-toggle tittle-side-bar" id="a-events">
            <i id="icon-eventos" class="fas fa-calendar-week icon-class-admin"></i>
            <br>
            <label class="label-not-display" style="cursor: pointer;">Eventos</label>
        </a>
        <div class="collapse" id="collapseEvents">
            <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
                <li class="nav-item tittle-side-bar">
                    <button class="no-btn" type="button" id="btn-event-add" onclick="call_page_add_event()">Adicionar Evento</button><br>
                    <hr class="hr-centered d-flex align-items-center special-class-hr-special" id="hr-special">
                    <button class="no-btn" type="button" id="btn-events-see" onclick="call_page_see_events();">Ver Eventos</button>
                </li>
            </ul>
        </div>
    </li>
    <br>
    <li class="nav-item">
        <a class="nav-link py-3 dropdown-toggle tittle-side-bar" id="a-candidates" >
            <i id="icon-candidatos" class="fas fa-user-tie icon-class-admin"></i>
            <br>
            <label class="label-not-display" style="cursor: pointer;">Candidatos</label>
        </a>
        <div class="collapse" id="collapseCandidates">
            <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
                <li class="nav-item tittle-side-bar">
                    <button class="no-btn" type="button" id="btn-candidate-add" onclick="call_page_add_candidate()">Adicionar Candidato</button><br>
                    <hr class="hr-centered d-flex align-items-center special-class-hr-special" id="hr-special">
                    <button class="no-btn" type="button" id="btn-candidates-see" onclick="call_page_see_candidates();">Ver Candidatos</button>
                </li>
            </ul>
        </div>
    </li>
    <br>
    <li class="nav-item">
        <a class="nav-link py-3 dropdown-toggle tittle-side-bar" id="a-documents">
            <i id="icon-documentos" class="fas fa-id-card icon-class-admin"></i>
            <br>
            <label class="label-not-display" style="cursor: pointer;">Documentos</label>
        </a>
        <div class="collapse" id="collapseDoc">
            <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
                <li class="nav-item tittle-side-bar">
                    <button class="no-btn" type="button" id="btn-doc-add" onclick="call_page_add_document()">Adicionar Documento</button><br>
                    <hr class="hr-centered d-flex align-items-center special-class-hr-special" id="hr-special">
                    <button class="no-btn" type="button" id="btn-docs-see" onclick="call_page_see_documents();">Ver Documentos</button>
                </li>
            </ul>
        </div>
    </li>
    <br>
    <br>
    <div id="avatar" class="border-top d-flex align-items-left justify-content-left p-3 link-dark text-decoration-none div-avatar">
        <i style="color: #f7b03e;" class="fas fa-user" id="ico-user"></i>&nbsp;&nbsp;<h6 id="name-avatar"><?php echo utf8_encode($_SESSION['user_name']); ?></h6>
    </div>
</ul>