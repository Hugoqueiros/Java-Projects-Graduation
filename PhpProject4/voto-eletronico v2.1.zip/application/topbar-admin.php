<?php include "header.php"; ?>
<nav class="navbar navbar-expand navbar-dark topbar static-top" style="background-color:#23262D;" aria-label="Fourth navbar example">
    <div class="container-fluid">
        <button type="button" class="no-btn" onclick="toggleMenu();"><i class="fas fa-bars icon-class-admin"></i></button>

        <div class="collapse navbar-collapse" id="navbarsExample04">
            <ul class="navbar-nav me-auto mb-2 mb-md-0">
            </ul>
            <span style="color: #fff;" id="clock"></span>&nbsp;&nbsp;&nbsp;
            <a style="text-decoration: none;margin-bottom: -5px;" href="https://voto-eletronico.jbr-projects.pt/admin/admin.php?f=logout_admin"><button type="button" style="margin-bottom: -5px;display:inline-flex;" class="no-btn tittle-side-bar"><i class="fas fa-power-off icon-class-admin"></i>&nbsp;&nbsp;Sair da Conta</button></a>
        </div>
    </div>
</nav>