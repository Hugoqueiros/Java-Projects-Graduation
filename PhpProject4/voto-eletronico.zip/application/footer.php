<script src="https://voto-eletronico.jbr-projects.pt/assets/js/jquery-3.6.0.min.js"></script>
<script src="https://kit.fontawesome.com/3d091f81e9.js" crossorigin="anonymous"></script>
<script src="https://voto-eletronico.jbr-projects.pt/assets/sweetalert2-7.26.11/dist/sweetalert2.all.js"></script>
<script src="https://voto-eletronico.jbr-projects.pt/assets/js/scripts.js"></script>
<script src="https://voto-eletronico.jbr-projects.pt/assets/js/dist/jquery.table2excel.js"></script>
</body>
</html>