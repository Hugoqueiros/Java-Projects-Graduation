<?php
require '../application/header.php';
include "admin.php";
session_start();
if ($_SESSION['user_role'] != 1) {
    ?>
    <div id="login_admin_total_div">
        <div id="login_admin_second_div">
            <!-- Login do administrador -->
            <h1>Login</h1>
            <?php if (isset($_SESSION['no_result'])) {
                ?> 
                <h5 style="color: red;">Administrador não existe!</h5>
            <?php } ?>
            <div>
                <label>Email: </label>
                <input id="admin_email" type="email">
                <span class="helper-error" id="helper-error-admin-email"></span>
            </div>     
            <br>
            <div>
                <label>Password: </label>
                <input id="admin_password" type="password">
                <span class="helper-error" id="helper-error-admin-password"></span>
            </div>
            <div id="recover_admin_password">
                <a id="forget_password_admin" href="#">Esqueceu-se da sua password?</a>
            </div>
            <br>
            <button id="btn_next" onclick="admin_login();">Entrar</button>
        </div>
    </div>
    <?php
} else {
    print_r($_SESSION);
    ?>    
    <a href="https://voto-eletronico.jbr-projects.pt/admin/admin.php?f=logout_admin" type="button">Sair da Conta</a>
    <div id="tipos_de_documento">
        <h1>Tipos de Documento</h1>
        <div>
            <label>Nome do Documento: </label>
            <input id="add_document_name">
            <span class="helper-error" id="helper-error-add-document-name"></span>
        </div>
        <br>
        <button type="button" onclick="add_doc();">Adicionar Documento </button>
        <br>
        <br>
        <table id="dtb_tipos_de_documento" style="width:100%">
            <thead>
                <tr>
                    <th>Nome do Documento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_docs = get_docs();
                while ($row = mysqli_fetch_assoc($result_docs)) {
                    ?>
                    <tr>
                        <th><?php echo utf8_encode($row['doc_name']); ?></th>
                        <th><button type="button" title="Editar Documento" onclick="edit_document(<?php echo $row['doc_id']; ?>);"><i class="fas fa-edit"></i></button>&nbsp;&nbsp;<button type="button" title="Eliminar Documento" onclick="delete_document_type(<?php echo $row['doc_id']; ?>);"><i class="fas fa-trash"></i></button></th>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <div id="utilizadores">
        <h1>Utilizadores</h1>
        <div>
            <label>Nome do Utilizador: </label>
            <input id="add_user_name">
            <span class="helper-error" id="helper-error-add-user-name"></span>
        </div>
        <div>
            <label>Email: </label>
            <input id="add_user_email" type="email">
            <span class="helper-error" id="helper-error-add-user-email"></span>
        </div>
        <div>
            <label>Password: </label>
            <input id="add_user_password" type="password">
            <span class="helper-error" id="helper-error-add-user-password"></span>
        </div>
        <div>
            <label>Confirmar Password: </label>
            <input id="add_user_confirm_password" type="password">
            <span class="helper-error" id="helper-error-add-user-confirm-password"></span>
        </div>
        <div>
            <label for="add_user_doc">Tipo do documento: </label>
            <select name="add_user_doc" id="add_user_doc">     
                <option selected disabled>Selecione uma opção</option>
                <?php
                $result_docs = get_docs();
                while ($row = mysqli_fetch_assoc($result_docs)) {
                    ?>
                    <option value="<?php echo utf8_encode($row['doc_id']); ?>"><?php echo utf8_encode($row['doc_name']); ?></option>     
                    <?php
                }
                ?>           
            </select>
            <span class="helper-error" id="helper-error-add-user-doc_type"></span>
        </div>
        <div id="div_add_user_nmri">
            <label>Numero de Identificação: </label>
            <input id="add_user_nmri" maxlength="11" onkeypress="return only_numbers(event)">
            <span class="helper-error" id="helper-error-add-user-nmri"></span>
        </div>
        <br>
        <button type="button" onclick="add_user();">Adicionar Utilizador</button>
        <br>
        <br>
        <table id="dtb_utilizadores" style="width:100%">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo de Documento</th>
                    <th>Número de Identificação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_users = get_users();
                while ($row = mysqli_fetch_assoc($result_users)) {
                    ?>
                    <tr>
                        <th><?php echo utf8_encode($row['user_name']); ?></th>
                        <th><?php echo utf8_encode($row['user_email']); ?></th>
                        <th><?php echo utf8_encode($row['doc_name']); ?></th>
                        <th><?php echo utf8_encode($row['user_nmri']); ?></th>             
                        <th><button type="button" title="Editar Utilizador" onclick="edit_user(<?php echo $row['user_id']; ?>);"><i class="fas fa-edit"></i></button>&nbsp;&nbsp;<button name="btn_delete_user" type="button" title="Eliminar Utilizador" onclick="delete_user(<?php echo $row['user_id']; ?>);"><i class="fas fa-trash"></i></button></th>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <div id="eventos">
        <h1>Eventos</h1>
        <div>
            <label>Titulo do Evento: </label>
            <input id="add_event_title">
            <span class="helper-error" id="helper-error-add-event-title"></span>
        </div>
        <div>
            <label>Descrição do Evento: </label>
            <input id="add_event_description">
            <span class="helper-error" id="helper-error-add-event-description"></span>
        </div>
        <div>
            <label>Data inicial: </label>
            <input id="add_event_date_ini" type="date">
            <span class="helper-error" id="helper-error-add-event-date-ini"></span>
        </div>
        <div>
            <label>Data de Expiração: </label>
            <input id="add_event_date_exp" type="date">
            <span class="helper-error" id="helper-error-add-event-date-exp"></span>
        </div>
        <div>
            <label for="add_event_doc">Tipo do documento: </label>
            <select name="add_event_doc" id="add_event_doc">     
                <option selected disabled>Selecione uma opção</option>
                <?php
                $result_docs = get_docs();
                while ($row = mysqli_fetch_assoc($result_docs)) {
                    ?>
                    <option value="<?php echo utf8_encode($row['doc_id']); ?>"><?php echo utf8_encode($row['doc_name']); ?></option>     
                    <?php
                }
                ?>           
            </select>
            <span class="helper-error" id="helper-error-add-event-doc_type"></span>
        </div>
        <br>
        <button type="button" onclick="add_event();"> Adicionar Evento </button>
        <br>
        <br>
        <table id="dtb_eventos" style="width:100%">
            <thead>
                <tr>
                    <th>Nº</th>
                    <th>Título</th>
                    <th>Data Inicial</th>
                    <th>Data de Expiração</th>
                    <th>Tipo de Documento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_events = get_events();

                $result_candidates = get_candidates();
                while ($row = mysqli_fetch_assoc($result_events)) {
                    $data_inicial = strtotime($row['event_date_ini']);
                    $verificacao = ceil(($data_inicial - time()) / 60 / 60 / 24);
                    $data_exp = strtotime($row['event_date_exp']);
                    $verificacao_final = ceil(($data_exp - time()) / 60 / 60 / 24);
                    ?>
                    <tr>
                        <th><?php echo $row['event_id']; ?></th>
                        <?php $result_event_candidate = get_event_candidates($row['event_id']); ?>
                        <th><?php echo utf8_encode($row['event_title']); ?></th>
                        <th><?php echo $row['event_date_ini']; ?></th>
                        <th><?php echo $row['event_date_exp']; ?></th>
                        <th><?php echo utf8_encode($row['doc_name']); ?></th>

                        <th><?php if (mysqli_num_rows($result_candidates) != 0 && $verificacao > 0) { ?><button type="button" title="Adicionar Candidato" onclick="add_candidate_toevent(<?php echo $row['event_id']; ?>);"><i class="fas fa-user-plus"></i></button>&nbsp;&nbsp;<?php }if (mysqli_num_rows($result_event_candidate) != 0 && $verificacao <= 0) { ?><button type="button" title="Ver Candidatos" onclick="see_candidates_event(<?php echo $row['event_id']; ?>);"><i class="fas fa-eye"></i></button>&nbsp;&nbsp;<?php } ?><?php if (mysqli_num_rows($result_event_candidate) != 0 && $verificacao > 0) { ?><button type="button" title="Ver Candidatos" onclick="see_candidates_event_delete(<?php echo $row['event_id']; ?>);"><i class="fas fa-eye"></i></button>&nbsp;&nbsp;<?php } ?><?php if ($verificacao_final < 0) { ?><button id="btn_see_events" title="Ver Resultados" onclick="see_results_event_admin(<?php echo $row['event_id']; ?>);"><i class="fas fa-poll"></i></button>&nbsp;&nbsp;<button type="button" title="Exportar Votos" onclick="export_votes(<?php echo $row['event_id']; ?>);"><i class="fas fa-file-download"></i></button>&nbsp;&nbsp;<?php } ?><?php if ($verificacao > 0) { ?><button type="button" title="Editar Evento" onclick="edit_event(<?php echo $row['event_id']; ?>);"><i class="fas fa-edit"></i></button>&nbsp;&nbsp;<?php } ?> <?php if ($verificacao > 0 || $verificacao_final < 0) { ?><button type="button" title="Eliminar Evento" onclick="delete_event(<?php echo $row['event_id']; ?>);"><i class="fas fa-trash"></i></button><?php } ?></th>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <div id="candidatos">
        <h1>Candidatos</h1>        
        <div>
            <label>Nome do Candidato: </label>
            <input id="add_candidate_name">
        </div>
        <div>
            <label>Partido do Candidato: </label>
            <input id="add_candidate_entourage">
        </div>
        <span class="helper-error" id="helper-error-add-candidate"></span>
        <br>
        <button type="button" onclick="add_candidate();"> Adicionar Candidato </button>
        <br>
        <br>
        <table id="dtb_candidatos" style="width:100%">
            <thead>
                <tr>
                    <th>Nome do Candidato</th>
                    <th>Partido do Candidato</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result_candidates)) {
                    ?>
                    <tr>
                        <?php if ($row['candidate_name'] == '') { ?>
                            <th>-----------------------</th>
                        <?php } else { ?>
                            <th><?php echo utf8_encode($row['candidate_name']); ?></th>
                        <?php } ?>
                        <?php if ($row['candidate_entourage'] == '') { ?>
                            <th>-----------------------</th>
                        <?php } else { ?>
                            <th><?php echo utf8_encode($row['candidate_entourage']); ?></th>
                        <?php } ?>                    
                        <th><button type="button" title="Editar Candidato" onclick="edit_candidate(<?php echo $row['candidate_id']; ?>);"><i class="fas fa-edit"></i></button>&nbsp;&nbsp;<button type="button" title="Eliminar Candidato" onclick="delete_candidate(<?php echo $row['candidate_id']; ?>);"><i class="fas fa-trash"></i></button></th>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>

    <?php
}
require '../application/footer.php';

