<?php
require 'application/header.php';
require 'user/user.php';
session_start();
if (!$_SESSION['user_name'] || $_SESSION['user_role'] != 0) {
    ?>
    <div id="login_user_total_div">
        <div id="login_user_second_div">
            <!-- Login do utilizador -->
            <h1>Login</h1>
            <?php if (isset($_SESSION['no_result'])) {
                ?> 
                <h5 style="color: red;">Utilizador não existe!</h5>
            <?php } ?>
            <div id="document_type_div">
                <label>Tipo do documento: </label>
                <select name="login_user_doc" id="login_user_doc">     
                    <option selected disabled>Selecione uma opção</option>
                    <?php
                    $result_docs = get_docs();
                    while ($row = mysqli_fetch_assoc($result_docs)) {
                        ?>
                        <option value="<?php echo utf8_encode($row['doc_id']); ?>"><?php echo utf8_encode($row['doc_name']); ?></option>     
                        <?php
                    }
                    ?>           
                </select>
                <span class="helper-error" id="helper-error-add-user-doc_type"></span>
            </div>
            <br>
            <div id="div_login_user_nmri">
                <label>Numero de Identificação: </label>
                <input id="login_user_nmri" maxlength="11" onkeypress="return only_numbers(event)">
                <span class="helper-error" id="helper-error-login-user-nmri"></span>
            </div>
            <br>
            <div id="pw">
                <label>Password: </label>
                <input id="login_user_password" type="password">
                <span class="helper-error" id="helper-error-login-password"></span>
            </div>
            <div id="recover_password">
                <a id="forget_password_user" href="#">Esqueceu-se da sua password?</a>
            </div>
            <br>
            <button id="btn_next" onclick="user_verify();" disabled>Seguinte</button>
            <br>
            <!-- Se o user existir vai inserir na div o input para a inserção da key enviada por email, através de jquery -->
            <div id="key">   
            </div>
        </div>
    </div>

    <?php
} else {
    print_r($_SESSION);
    ?>    
    <a href="https://voto-eletronico.jbr-projects.pt/user/user.php?f=logout_user" type="button">Sair da Conta</a>
    <?php if ($_SESSION['user_change_pw'] == 0) { ?>
        <input type="hidden" id="check_pw" value="<?php echo $_SESSION['user_change_pw'] ?>">
    <?php } ?>

    <div id="eventos_disponiveis">
        <h1>Eventos Disponiveis</h1>
        <p>Eventos disponiveis para votar:</p>
        <table id="dtb_eventos_disponiveis" style="width:100%"> 
            <thead>
                <tr>
                    <th>Nº do Evento</th>
                    <th>Título</th>
                    <th>Descrição</th>
                    <th>Data Inicial</th>
                    <th>Data de Expiração</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_event_user = get_event_users();
                while ($row = mysqli_fetch_assoc($result_event_user)) {
                    $data_inicial = strtotime($row['event_date_ini']);
                    $verificacao = ceil(($data_inicial - time()) / 60 / 60 / 24);
                    $data_exp = strtotime($row['event_date_exp']);
                    $verificacao_final = ceil(($data_exp - time()) / 60 / 60 / 24);
                    if ($verificacao <= 0 && $verificacao_final >= 0) {
                        ?>
                        <tr>
                            <th><?php echo $row['event_id']; ?></th>
                            <th><?php echo utf8_encode($row['event_title']); ?></th>
                            <?php if ($row['event_description'] == '') {
                                ?>
                                <th>-----------------------</th>
                            <?php } else { ?>
                                <th><?php echo utf8_encode($row['event_description']); ?></th>
                            <?php } ?>

                            <th><?php echo $row['event_date_ini']; ?></th>
                            <th><?php echo $row['event_date_exp']; ?></th>
                            <?php
                            $check_vote = check_vote($row['event_id']);
                            if ($check_vote == true) {
                                ?>
                                <th style="color:green;">Já votou neste evento</th>
                            <?php } else {
                                ?>
                                <th><button type="button" title="Votar" onclick="see_candidates_user_event(<?php echo $row['event_id']; ?>);"><i class="fas fa-plus"></i></button></th>
                                <?php
                            }
                            ?>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <div id="próximos_eventos">
        <h1>Próximos Eventos</h1>
        <p>Eventos nos próximos 15 dias:</p>
        <table id="dtb_proximos_eventos" style="width:100%">
            <thead>
                <tr>
                    <th>Nº do Evento</th>
                    <th>Título</th>
                    <th>Descrição</th>
                    <th>Data Inicial</th>
                    <th>Data de Expiração</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_event_user_two = get_event_users();
                while ($row = mysqli_fetch_assoc($result_event_user_two)) {
                    $data_inicial = strtotime($row['event_date_ini']);
                    $verificacao = ceil(($data_inicial - time()) / 60 / 60 / 24);
                    $data_exp = strtotime($row['event_date_exp']);
                    $verificacao_final = ceil(($data_exp - time()) / 60 / 60 / 24);
                    if ($verificacao <= 14 && $verificacao > 0) {
                        ?>
                        <tr>
                            <th><?php echo $row['event_id']; ?></th>
                            <th><?php echo utf8_encode($row['event_title']); ?></th>
                            <?php if ($row['event_description'] == '') {
                                ?>
                                <th>-----------------------</th>
                            <?php } else { ?>
                                <th><?php echo utf8_encode($row['event_description']); ?></th>
                            <?php } ?>

                            <th><?php echo $row['event_date_ini']; ?></th>
                            <th><?php echo $row['event_date_exp']; ?></th>
                            <th style="color:#d8a30c;">Ainda não é possivel votar neste evento</th>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <div id="historico_eventos">
        <h1>Histórico de Eventos</h1>
        <p>Eventos nos últimos 15 dias:</p>
        <table id="dtb_historico_eventos" style="width:100%">
            <thead>
                <tr>
                    <th>Nº do Evento</th>
                    <th>Título</th>
                    <th>Descrição</th>
                    <th>Data Inicial</th>
                    <th>Data de Expiração</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result_event_user_two = get_event_users();
                while ($row = mysqli_fetch_assoc($result_event_user_two)) {
                    $data_inicial = strtotime($row['event_date_ini']);
                    $verificacao = ceil(($data_inicial - time()) / 60 / 60 / 24);
                    $data_exp = strtotime($row['event_date_exp']);
                    $verificacao_final = ceil(($data_exp - time()) / 60 / 60 / 24);
                    if ($verificacao_final >= -14 && $verificacao_final < 0) {
                        ?>
                        <tr>
                            <th><?php echo $row['event_id']; ?></th>
                            <th><?php echo utf8_encode($row['event_title']); ?></th>
                            <?php if ($row['event_description'] == '') {
                                ?>
                                <th>-----------------------</th>
                            <?php } else { ?>
                                <th><?php echo utf8_encode($row['event_description']); ?></th>
                            <?php } ?>

                            <th><?php echo $row['event_date_ini']; ?></th>
                            <th><?php echo $row['event_date_exp']; ?></th>
                            <th><button id="btn_see_events" title="Ver Resultados" onclick="see_results_event(<?php echo $row['event_id']; ?>);"><i class="fas fa-poll"></i></button></th>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
    <?php
}
require 'application/footer.php';
?>
