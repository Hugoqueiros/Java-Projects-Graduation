<?php
require 'header.php';
require 'Db_connection.php';
if ($_GET['email'] && $_GET['key']) {
    $email = $_GET['email'];
    $key = $_GET['key'];
    $role = $_GET['role'];
    $query = mysqli_query(
            $connection, "SELECT * FROM `users` WHERE `user_key`='" . $key . "' AND `user_email`='" . $email . "'AND `user_role`='" . $role . "'"
    );
    $curDate = date("Y-m-d H:i:s");
    if (mysqli_num_rows($query) > 0) {
        $row = mysqli_fetch_array($query);
        if ($row['user_exp_pw_date'] >= $curDate) {
            ?>
            <div>
                <label>Password:</label>
                <input type="password" id='change_password'>
                <span class="helper-error" id="helper-error-login-recoverpw-password"></span>
            </div>
            <div>
                <label>Confirmar Password:</label>
                <input type="password" id='change_confirm_password'>
                <span class="helper-error" id="helper-error-login-recoverpw-confirm-password"></span>
            </div>
            <button type="button" onclick="recover_password('<?php echo $email; ?>', '<?php echo $role; ?>', '<?php echo $key; ?>');">Alterar Password</button>
            <?php
        } else {
            echo '<p>O tempo para a alteração da password expirou</p>';
        }
    } else {
        echo '<p>O tempo para a alteração da password expirou</p>';
    }
}
require 'footer.php';
?>