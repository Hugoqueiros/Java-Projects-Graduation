<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <title>Voto Eletrónico</title>
        <style>
            table, th, td {
                border: 1px solid black;
                border-collapse: collapse;
            }
            th, td {
                padding: 5px;
                text-align: left;
            }
        </style>
        <link href="https://voto-eletronico.jbr-projects.pt/assets/sweetalert2-7.26.11/dist/sweetalert2.css" rel="stylesheet">
        <link rel="stylesheet" href="https://voto-eletronico.jbr-projects.pt/assets/css/styles.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css"/>
    </head>
    <body>